//
//  main.m
//  MyJoystickDemo
//
//  Created by Daniel Witurna on 20.07.14.
//  Copyright Daniel Witurna 2014. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, @"AppDelegate");
        return retVal;
    }
}
