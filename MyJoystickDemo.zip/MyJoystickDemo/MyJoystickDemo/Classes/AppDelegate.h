//
//  AppDelegate.h
//  MyJoystickDemo
//
//  Created by Daniel Witurna on 20.07.14.
//  Copyright Daniel Witurna 2014. All rights reserved.
//
// -----------------------------------------------------------------------

#import "cocos2d.h"

@interface AppDelegate : CCAppDelegate
@end
